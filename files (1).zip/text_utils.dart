// ============================================================
// text_utils.dart – Làm sạch văn bản + cắt nhỏ file lớn
// ============================================================

/// 1) Làm sạch ký tự đặc biệt để giọng đọc không đọc "ba gạch ngang", "móc vuông"...
String cleanText(String input) {
  var t = input.replaceAll('\r\n', '\n').replaceAll('\r', '\n');

  // Bỏ link
  t = t.replaceAll(RegExp(r'https?://\S+'), ' ');

  // Bỏ cả dòng chỉ chứa ký tự trang trí: ---  ***  >>>  ===  ___  ~~~  ###
  t = t.replaceAll(RegExp(r'^[\s\-\*=_~>#•·\.]{3,}$', multiLine: true), '');

  // Bỏ dải ký tự trang trí nằm giữa dòng: --  **  >>  <<  ==  __
  t = t.replaceAll(RegExp(r'(-{2,}|\*{2,}|>{2,}|<{2,}|={2,}|_{2,}|~{2,})'), ' ');

  // Ngoặc kiểu Nhật/Trung: bỏ ngoặc, giữ nội dung bên trong  【】「」『』《》〈〉〔〕［］｛｝
  t = t.replaceAll(RegExp(r'[【】「」『』《》〈〉〔〕［］｛｝]'), ' ');

  // Ký tự markdown còn sót
  t = t.replaceAll(RegExp(r'[*_#`~^|\\]'), ' ');

  // Emoji, ký hiệu (\p{S}) và ký tự điều khiển định dạng (\p{Cf})
  t = t.replaceAll(RegExp(r'[\p{S}\p{Cf}]', unicode: true), ' ');

  // Dấu câu lặp: "?!?!" -> "?",  "......" -> "..."
  t = t.replaceAll(RegExp(r'([!?])[!?]+'), r'$1');
  t = t.replaceAll(RegExp(r'\.{4,}'), '...');

  // Chuẩn hoá khoảng trắng; mỗi dòng phải kết thúc bằng dấu câu để TTS ngắt nghỉ đúng
  final lines = t.split('\n').map((line) {
    var l = line.replaceAll(RegExp(r'[ \t\u00A0]+'), ' ').trim();
    if (l.isEmpty) return '';
    if (!RegExp(r'''[.!?…:;,"”’'»)]$''').hasMatch(l)) l = '$l.';
    return l;
  });
  t = lines.join('\n');
  t = t.replaceAll(RegExp(r'\n{3,}'), '\n\n');
  return t.trim();
}

/// 2) Cắt văn bản thành các đoạn < [maxChars] ký tự, cắt theo dấu . ! ? …
/// (API Google TTS giới hạn 5000 BYTE/lần gọi; tiếng Việt có dấu ~1.4–2 byte/ký tự
/// nên 2000 ký tự là mức an toàn.)
List<String> splitTextIntoChunks(String text, {int maxChars = 2000}) {
  final chunks = <String>[];
  final buf = StringBuffer();

  void flush() {
    final s = buf.toString().trim();
    if (s.isNotEmpty) chunks.add(s);
    buf.clear();
  }

  // Tách thành từng câu: sau . ! ? … hoặc khi xuống dòng
  final sentences = text.split(RegExp(r'(?<=[.!?…])\s+|\n+'));
  for (final raw in sentences) {
    final s = raw.trim();
    if (s.isEmpty) continue;

    // Câu quá dài (không có dấu chấm) -> cắt cứng theo dấu phẩy/khoảng trắng
    if (s.length > maxChars) {
      flush();
      chunks.addAll(_hardSplit(s, maxChars));
      continue;
    }
    if (buf.length + s.length + 1 > maxChars) flush();
    if (buf.isNotEmpty) buf.write(' ');
    buf.write(s);
  }
  flush();
  return chunks;
}

Iterable<String> _hardSplit(String s, int max) sync* {
  var rest = s;
  while (rest.length > max) {
    var cut = rest.lastIndexOf(RegExp(r'[,;:]\s'), max);
    if (cut < max ~/ 2) cut = rest.lastIndexOf(' ', max);
    if (cut <= 0) cut = max - 1;
    yield rest.substring(0, cut + 1).trim();
    rest = rest.substring(cut + 1).trim();
  }
  if (rest.isNotEmpty) yield rest;
}

/// 3) Parse cả cuốn truyện: làm sạch -> tách chương -> cắt đoạn.
/// Là hàm top-level để chạy trong isolate (compute) – không làm đơ UI với file 10MB.
Map<String, dynamic> parseBook(String raw) {
  final cleaned = cleanText(raw);
  final chapterRe = RegExp(r'^(?:chương|chapter|hồi)\s*\d+',
      caseSensitive: false, unicode: true);

  final titles = <String>['Mở đầu'];
  final bodies = <StringBuffer>[StringBuffer()];
  for (final line in cleaned.split('\n')) {
    final l = line.trim();
    if (l.isNotEmpty && l.length < 120 && chapterRe.hasMatch(l)) {
      titles.add(l.replaceAll(RegExp(r'\.$'), ''));
      bodies.add(StringBuffer());
    }
    bodies.last.writeln(line);
  }

  final chunks = <String>[];
  final outTitles = <String>[];
  final starts = <int>[];
  for (var i = 0; i < titles.length; i++) {
    final c = splitTextIntoChunks(bodies[i].toString());
    if (c.isEmpty) continue;
    outTitles.add(titles[i]);
    starts.add(chunks.length);
    chunks.addAll(c);
  }
  if (outTitles.length == 1 && outTitles[0] == 'Mở đầu') outTitles[0] = 'Toàn bộ';
  return {'chunks': chunks, 'titles': outTitles, 'starts': starts};
}
