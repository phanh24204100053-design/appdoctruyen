# Đọc Truyện – App Flutter đọc file .txt bằng giọng nữ anime (Google Cloud TTS)

## 1. Cài đặt dự án
```bash
flutter create --platforms=android story_reader_app
cd story_reader_app
# Chép đè: pubspec.yaml và cả thư mục lib/ từ bộ code này
flutter pub get
```

## 2. Sửa `android/app/src/main/AndroidManifest.xml`
Thêm quyền Internet (ngay trong `<manifest>`, trước `<application>`):
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```
Trong thẻ `<activity android:name=".MainActivity" ...>`: đổi `launchMode` thành `singleTask` và thêm 2 intent-filter để app xuất hiện trong menu "Chia sẻ / Mở bằng":
```xml
<activity
    android:name=".MainActivity"
    android:launchMode="singleTask" ... >

    <!-- Nhận file .txt khi bấm Chia sẻ (Share) -->
    <intent-filter>
        <action android:name="android.intent.action.SEND" />
        <category android:name="android.intent.category.DEFAULT" />
        <data android:mimeType="text/plain" />
    </intent-filter>
    <!-- Nhận khi chọn "Mở bằng" từ trình quản lý file -->
    <intent-filter>
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <data android:mimeType="text/plain" />
    </intent-filter>
    ...
</activity>
```

## 3. Lấy Google Cloud TTS API Key
1. Vào https://console.cloud.google.com → tạo Project mới.
2. Bật **Billing** (bắt buộc dù dùng gói miễn phí; cần thẻ thanh toán).
3. **APIs & Services → Library** → tìm **Cloud Text-to-Speech API** → **Enable**.
4. **APIs & Services → Credentials → Create credentials → API key**.
5. Bấm **Restrict key** → *API restrictions* → chỉ chọn **Cloud Text-to-Speech API**.
   (Đừng dùng "Android apps restriction": app gọi REST thẳng nên không gửi chứng chỉ ứng dụng.)
6. **Billing → Budgets & alerts**: đặt cảnh báo ngân sách (vd. $5) để tránh bị trừ tiền bất ngờ.
7. Mở app → biểu tượng ⚙ → dán key (dạng `AIza...`) → Lưu.

## 4. Chạy thử & build APK
```bash
flutter run                          # cắm điện thoại bật USB debugging
flutter build apk --release          # file: build/app/outputs/flutter-apk/app-release.apk
flutter build apk --split-per-abi    # (tuỳ chọn) APK nhỏ hơn cho từng kiến trúc CPU
```
Chép `app-release.apk` vào điện thoại → mở file → cho phép "Cài ứng dụng không rõ nguồn gốc" → cài.
(Dùng cá nhân thì không cần keystore; muốn đưa lên Google Play thì phải ký bằng keystore riêng.)

## 5. Cách hoạt động
- `cleanText()` (text_utils.dart): xoá `--- *** >>> 【】「」`, link, emoji, markdown; đảm bảo cuối dòng có dấu câu để TTS ngắt nghỉ.
- `splitTextIntoChunks()`: cắt theo `. ! ? …`, mỗi đoạn ≤ 2000 ký tự (API giới hạn 5000 **byte**/lần).
- `parseBook()`: chạy trong isolate (không đơ UI), tự tách chương theo dòng bắt đầu bằng "Chương N / Chapter N / Hồi N".
- Đọc **theo yêu cầu**: chỉ gọi API cho đoạn đang nghe + tải trước 1 đoạn kế tiếp, có cache → không tốn tiền cho phần chưa nghe.
- Vị trí đọc lưu theo từng file (SharedPreferences), mở lại app là đọc tiếp.
- Pitch 2.0 và speaking_rate 1.1 nằm ở `ReaderController` (hằng `pitch`, `speakingRate`); chỉnh tại đó nếu muốn giọng khác.

## 6. Giới hạn đã biết
- Màn hình tắt thì Android có thể dừng phát. Muốn đọc nền ổn định: thêm gói `just_audio_background` (cần khai báo service trong manifest).
- Tua ±10s hoạt động trong từng đoạn (~2 phút âm thanh); tua vượt biên sẽ nhảy sang đoạn kế/trước.
- Muốn đổi sang Vbee/ElevenLabs/Zalo TTS: chỉ cần viết lại hàm `_synthesize()` (trả về bytes MP3).
- Tôi chưa chạy thử trên máy thật; nếu `flutter pub get` hoặc build báo lỗi phiên bản gói, gửi log cho tôi sửa.
