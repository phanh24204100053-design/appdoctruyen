// ============================================================
// main.dart – Giao diện app đọc truyện
// ============================================================
import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';

import 'reader_controller.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const StoryReaderApp());
}

class StoryReaderApp extends StatelessWidget {
  const StoryReaderApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Đọc Truyện',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.pinkAccent, useMaterial3: true),
        home: const ReaderPage(),
      );
}

class ReaderPage extends StatefulWidget {
  const ReaderPage({super.key});
  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  final c = ReaderController();
  StreamSubscription? _shareSub;

  @override
  void initState() {
    super.initState();
    c.init();
    _initSharing();
  }

  /// "Gửi file .txt vào app": nhận file chia sẻ từ app khác (Files, Zalo, Telegram...)
  void _initSharing() {
    ReceiveSharingIntent.instance.getInitialMedia().then((files) {
      _onShared(files);
      ReceiveSharingIntent.instance.reset();
    });
    _shareSub = ReceiveSharingIntent.instance.getMediaStream().listen(_onShared);
  }

  Future<void> _onShared(List<SharedMediaFile> files) async {
    if (files.isEmpty) return;
    final f = files.first;
    if (f.type == SharedMediaType.text) {
      // Người dùng chia sẻ thẳng đoạn text -> lưu tạm thành file rồi đọc
      final dir = await getTemporaryDirectory();
      final tmp = File('${dir.path}/shared_text.txt');
      await tmp.writeAsString(f.path);
      c.openBook(tmp.path);
    } else {
      c.openBook(f.path);
    }
  }

  Future<void> _pick() async {
    final r = await FilePicker.platform
        .pickFiles(type: FileType.custom, allowedExtensions: ['txt']);
    final path = r?.files.single.path;
    if (path != null) c.openBook(path);
  }

  Future<void> _settings() async {
    final ctrl = TextEditingController(text: c.apiKey);
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Google Cloud TTS API Key'),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(hintText: 'AIza...'),
          autocorrect: false,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Huỷ')),
          FilledButton(
            onPressed: () {
              c.saveApiKey(ctrl.text);
              Navigator.pop(context);
            },
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _shareSub?.cancel();
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: Text(c.hasBook ? c.bookTitle : 'Đọc Truyện',
              overflow: TextOverflow.ellipsis),
          actions: [
            IconButton(icon: const Icon(Icons.folder_open), onPressed: _pick),
            IconButton(icon: const Icon(Icons.settings), onPressed: _settings),
          ],
        ),
        drawer: _chapterDrawer(),
        body: c.hasBook ? _reader(context) : _empty(),
      ),
    );
  }

  Widget _empty() => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (c.loading) ...[
              const CircularProgressIndicator(),
              const SizedBox(height: 12),
              const Text('Đang xử lý file...'),
            ] else ...[
              const Icon(Icons.menu_book, size: 72),
              const SizedBox(height: 12),
              const Text(
                'Chọn file .txt hoặc chia sẻ (Share) file .txt vào app này.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                  onPressed: _pick,
                  icon: const Icon(Icons.upload_file),
                  label: const Text('Chọn file .txt')),
              if (c.error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: Text(c.error!, style: const TextStyle(color: Colors.red)),
                ),
            ],
          ]),
        ),
      );

  Widget _chapterDrawer() => Drawer(
        child: SafeArea(
          child: Column(children: [
            const ListTile(title: Text('Danh sách chương')),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                itemCount: c.chapterTitles.length,
                itemBuilder: (_, i) => ListTile(
                  dense: true,
                  selected: i == c.currentChapter,
                  title: Text(c.chapterTitles[i], maxLines: 2, overflow: TextOverflow.ellipsis),
                  onTap: () {
                    Navigator.pop(context);
                    c.jumpToChapter(i);
                  },
                ),
              ),
            ),
          ]),
        ),
      );

  Widget _reader(BuildContext context) {
    final progress = (c.index + 1) / c.chunks.length;
    return Column(children: [
      LinearProgressIndicator(value: progress),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: Text(
          '${c.chapterTitles[c.currentChapter]}  •  đoạn ${c.index + 1}/${c.chunks.length}',
          style: Theme.of(context).textTheme.labelMedium,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      Expanded(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: SelectableText(c.chunks[c.index],
              style: const TextStyle(fontSize: 17, height: 1.6)),
        ),
      ),
      if (c.error != null)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(c.error!,
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.red)),
        ),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(
            iconSize: 32,
            icon: const Icon(Icons.skip_previous),
            onPressed: c.index > 0 ? () => c.jumpToChunk(c.index - 1) : null),
        IconButton(
            iconSize: 36,
            icon: const Icon(Icons.replay_10),
            onPressed: () => c.skip(-10)),
        FloatingActionButton(
          onPressed: c.loading ? null : c.togglePlay,
          child: c.loading
              ? const SizedBox(
                  width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 3))
              : Icon(c.playing ? Icons.pause : Icons.play_arrow, size: 36),
        ),
        IconButton(
            iconSize: 36,
            icon: const Icon(Icons.forward_10),
            onPressed: () => c.skip(10)),
        IconButton(
            iconSize: 32,
            icon: const Icon(Icons.skip_next),
            onPressed:
                c.index + 1 < c.chunks.length ? () => c.jumpToChunk(c.index + 1) : null),
      ]),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
        child: Row(children: [
          const Icon(Icons.speed),
          const SizedBox(width: 8),
          DropdownButton<double>(
            value: c.speed,
            items: [0.75, 1.0, 1.25, 1.5, 2.0]
                .map((v) => DropdownMenuItem(value: v, child: Text('${v}x')))
                .toList(),
            onChanged: (v) => v != null ? c.setSpeed(v) : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: DropdownButton<String>(
              isExpanded: true,
              value: c.voiceId,
              items: kVoices
                  .map((v) => DropdownMenuItem(
                      value: v.id, child: Text(v.label, overflow: TextOverflow.ellipsis)))
                  .toList(),
              onChanged: (v) => v != null ? c.setVoice(v) : null,
            ),
          ),
        ]),
      ),
    ]);
  }
}
