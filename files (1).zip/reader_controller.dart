// ============================================================
// reader_controller.dart – Gọi Google TTS, phát nối tiếp, lưu vị trí
// ============================================================
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'text_utils.dart';

class VoiceOption {
  final String id, label;
  const VoiceOption(this.id, this.label);
}

/// Các giọng NỮ tiếng Việt của Google Cloud TTS
const kVoices = [
  VoiceOption('vi-VN-Wavenet-C', 'Wavenet C – nữ, sáng (khuyên dùng)'),
  VoiceOption('vi-VN-Wavenet-A', 'Wavenet A – nữ, ấm'),
  VoiceOption('vi-VN-Standard-C', 'Standard C – nữ (rẻ hơn)'),
  VoiceOption('vi-VN-Standard-A', 'Standard A – nữ (rẻ hơn)'),
];

class ReaderController extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();
  late SharedPreferences _prefs;
  late Directory _cacheDir;

  // ---- Cài đặt giọng ----
  String apiKey = '';
  String voiceId = 'vi-VN-Wavenet-C';
  double speed = 1.0; // tốc độ phát lại (player)
  static const double pitch = 2.0; // cao độ -> chất giọng "anime"
  static const double speakingRate = 1.1; // tốc độ đọc gửi lên API

  // ---- Dữ liệu truyện ----
  String bookTitle = '';
  String _bookId = '';
  List<String> chunks = [];
  List<String> chapterTitles = [];
  List<int> chapterStarts = [];
  int index = 0; // đoạn đang đọc

  // ---- Trạng thái ----
  bool loading = false;
  bool playing = false;
  String? error;

  int _session = 0; // mỗi lần nhảy đoạn tăng 1 để huỷ tác vụ cũ
  final Map<int, Future<File>> _pending = {};
  ProcessingState _lastPs = ProcessingState.idle;

  bool get hasBook => chunks.isNotEmpty;

  int get currentChapter {
    var k = 0;
    for (var i = 0; i < chapterStarts.length; i++) {
      if (chapterStarts[i] <= index) k = i;
    }
    return k;
  }

  // ------------------------------------------------------------
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _cacheDir = Directory('${(await getTemporaryDirectory()).path}/tts_cache');
    await _cacheDir.create(recursive: true);

    apiKey = _prefs.getString('apiKey') ?? '';
    voiceId = _prefs.getString('voice') ?? voiceId;
    speed = _prefs.getDouble('speed') ?? 1.0;

    _player.playerStateStream.listen((s) {
      playing = s.playing && s.processingState != ProcessingState.completed;
      // Hết đoạn -> tự động đọc đoạn kế tiếp (nối tiếp, không ngắt quãng)
      if (s.processingState == ProcessingState.completed &&
          _lastPs != ProcessingState.completed) {
        _onChunkDone();
      }
      _lastPs = s.processingState;
      notifyListeners();
    });

    final last = _prefs.getString('lastBook');
    if (last != null && File(last).existsSync()) await openBook(last);
    notifyListeners();
  }

  Future<void> saveApiKey(String key) async {
    apiKey = key.trim();
    await _prefs.setString('apiKey', apiKey);
    error = null;
    notifyListeners();
  }

  // ------------------------------------------------------------
  /// Mở file .txt: đọc, làm sạch, tách chương, cắt đoạn (trong isolate)
  Future<void> openBook(String path) async {
    await _stop();
    loading = true;
    error = null;
    notifyListeners();
    try {
      final bytes = await File(path).readAsBytes();
      final raw = utf8.decode(bytes, allowMalformed: true);
      final m = await compute(parseBook, raw);
      final c = List<String>.from(m['chunks'] as List);
      if (c.isEmpty) throw 'File không có nội dung.';

      chunks = c;
      chapterTitles = List<String>.from(m['titles'] as List);
      chapterStarts = List<int>.from(m['starts'] as List);

      final name = path.split('/').last;
      bookTitle = name.replaceAll(RegExp(r'\.txt$', caseSensitive: false), '');
      _bookId = '${name}_${bytes.length}'; // định danh sách để lưu vị trí
      index = (_prefs.getInt('pos_$_bookId') ?? 0).clamp(0, c.length - 1);
      await _prefs.setString('lastBook', path);
    } catch (e) {
      error = 'Không đọc được file: $e';
    }
    loading = false;
    notifyListeners();
  }

  // ------------------------------------------------------------
  // Gọi Google Cloud TTS
  Future<Uint8List> _synthesize(String text) async {
    if (apiKey.isEmpty) throw 'Chưa nhập API Key (biểu tượng ⚙ ở góc trên).';
    final uri = Uri.parse(
        'https://texttospeech.googleapis.com/v1/text:synthesize?key=$apiKey');
    final res = await http
        .post(uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'input': {'text': text},
              'voice': {'languageCode': 'vi-VN', 'name': voiceId},
              'audioConfig': {
                'audioEncoding': 'MP3',
                'pitch': pitch,
                'speakingRate': speakingRate,
              },
            }))
        .timeout(const Duration(seconds: 30));
    if (res.statusCode != 200) throw 'TTS lỗi ${res.statusCode}: ${res.body}';
    return base64Decode(jsonDecode(res.body)['audioContent'] as String);
  }

  String _safe(String s) => s.replaceAll(RegExp(r'[^A-Za-z0-9]'), '_');
  File _fileFor(int i) =>
      File('${_cacheDir.path}/${_safe(_bookId)}_${voiceId}_$i.mp3');

  /// Lấy audio của đoạn i (có cache, tránh gọi API lặp lại = tiết kiệm tiền)
  Future<File> _audioFor(int i) {
    final f = _fileFor(i);
    final fut = _pending.putIfAbsent(i, () async {
      if (await f.exists()) return f;
      await f.writeAsBytes(await _synthesize(chunks[i]), flush: true);
      return f;
    });
    fut.catchError((_) {
      _pending.remove(i);
      return f;
    });
    return fut;
  }

  /// Dọn audio các đoạn đã nghe xong
  void _cleanup(int current) {
    for (final k in _pending.keys.where((k) => k < current - 1).toList()) {
      _pending.remove(k);
      _fileFor(k).delete().catchError((_) => _fileFor(k));
    }
  }

  // ------------------------------------------------------------
  Future<void> _playIndex(int i, {Duration? fromEnd}) async {
    final s = ++_session;
    index = i.clamp(0, chunks.length - 1);
    error = null;
    loading = true;
    notifyListeners();
    _prefs.setInt('pos_$_bookId', index); // lưu vị trí đang đọc
    try {
      final file = await _audioFor(index);
      if (s != _session) return;
      if (index + 1 < chunks.length) _audioFor(index + 1); // tải trước đoạn sau
      final dur = await _player.setFilePath(file.path);
      if (s != _session) return;
      await _player.setSpeed(speed);
      if (fromEnd != null && dur != null) {
        final t = dur - fromEnd;
        await _player.seek(t < Duration.zero ? Duration.zero : t);
      }
      loading = false;
      notifyListeners();
      _player.play(); // không await: future này kết thúc khi phát xong
      _cleanup(index);
    } catch (e) {
      if (s != _session) return;
      loading = false;
      error = '$e';
      notifyListeners();
    }
  }

  void _onChunkDone() {
    if (index + 1 < chunks.length) {
      _playIndex(index + 1);
    } else {
      playing = false;
      notifyListeners();
    }
  }

  Future<void> _stop() async {
    _session++;
    _pending.clear();
    await _player.stop();
  }

  // ---------------- Điều khiển cho UI ----------------
  Future<void> togglePlay() async {
    if (!hasBook) return;
    if (_player.playing) {
      await _player.pause();
    } else if (_player.processingState == ProcessingState.idle) {
      await _playIndex(index);
    } else {
      _player.play();
    }
  }

  Future<void> jumpToChunk(int i) => _playIndex(i);
  Future<void> jumpToChapter(int c) => _playIndex(chapterStarts[c]);

  /// Tua ±10 giây. Tua vượt đoạn -> chuyển sang đoạn kế/đoạn trước.
  Future<void> skip(int seconds) async {
    if (!hasBook || _player.processingState == ProcessingState.idle) return;
    final dur = _player.duration ?? Duration.zero;
    final target = _player.position + Duration(seconds: seconds);
    if (target < Duration.zero) {
      if (index > 0) {
        await _playIndex(index - 1, fromEnd: -target);
      } else {
        await _player.seek(Duration.zero);
      }
    } else if (dur > Duration.zero && target >= dur) {
      if (index + 1 < chunks.length) {
        await _playIndex(index + 1);
      } else {
        await _player.seek(dur);
      }
    } else {
      await _player.seek(target);
    }
  }

  Future<void> setSpeed(double v) async {
    speed = v;
    await _prefs.setDouble('speed', v);
    await _player.setSpeed(v);
    notifyListeners();
  }

  Future<void> setVoice(String id) async {
    voiceId = id;
    await _prefs.setString('voice', id);
    _pending.clear(); // cache cũ gắn với giọng cũ
    notifyListeners();
    if (hasBook && _player.processingState != ProcessingState.idle) {
      await _playIndex(index); // đọc lại đoạn hiện tại bằng giọng mới
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
